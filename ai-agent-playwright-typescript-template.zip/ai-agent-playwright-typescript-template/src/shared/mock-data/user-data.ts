import { User } from "shared/types";

export const NEW_USER: User = {
	name: "John Doe",
	email: "john@example.com",
};
