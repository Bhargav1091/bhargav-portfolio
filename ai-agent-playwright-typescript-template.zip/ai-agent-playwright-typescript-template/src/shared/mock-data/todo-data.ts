export const TODO_ITEMS: string[] = ["Buy milk", "Read book", "Write code"];
export const LOCAL_STORAGE_ID: string = "react-todos";
